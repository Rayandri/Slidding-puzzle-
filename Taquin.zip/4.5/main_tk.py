from classe_tk import *

f = Fenetre()
f.affichage()