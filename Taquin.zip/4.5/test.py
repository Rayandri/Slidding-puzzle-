""" test de RAM """
a = []
b = 9**25
while True:
    a.append(b)
